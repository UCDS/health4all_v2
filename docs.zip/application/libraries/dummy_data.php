<?php

class Dummy_data{
    public $admit_date=0;
    public $name="Name";
    public $age_years=0;
    public $age_months=0;
    public $age_days=0;
    public $department="Department";
    public $parent_spouse="Parent/Spouse";
    public $address="Address";
    public $place="Place";
    public $district="District";
    public $unit_name="Unit Name";
    public $area_name="Area Name";
    public $phone="000000000";
    public $mlc="0";
    public $mlc_number=1;
    public $ps_name=555;
    public $visit_name="Visit Name";
    public $gender="Gender";
    public $admit_time=0;
    public $hosp_file_no=555; 
    public $op_room_no=555;
    public $patient_id=555;
    public $first_name="First Name";
    public $last_name="Last Name";
}
?>