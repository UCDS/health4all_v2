
	<div style="float:right;width:800px;background:#eee;position:absolute;right:0;top:0;padding:10px;">
		<a href='<?php echo base_url();?>bloodbank/user_panel/appointment_bookings'>Appointment Report</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/donation_summary'>Donations Summary</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/report_donations'>Donations Detailed</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/issue_summary'>Issue Summary</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/hospital_issues'>Hospital Wise Issues</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/report_issue'>Issue Report</a> |
		<a href='<?php echo base_url();?>bloodbank/user_panel/available_blood'>Available Blood</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/report_inventory'>Inventory Detailed</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/blood_donors'>Donors report</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/report_screening'>Screening Report</a> | 
		<a href='<?php echo base_url();?>bloodbank/user_panel/report_grouping'>Grouping Report</a> |
		<a href='<?php echo base_url();?>bloodbank/user_panel/print_certificates'>Print Certificates</a> 
	</div>
