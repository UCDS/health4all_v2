</div>
<!-- End container -->
</div>
<!-- End Wrap -->

<div id="footer">
      <div class="container">
        <p class="text-muted">
		Health4All - a Free and Open Source application supported by <a href="http://www.yousee.in" target="_blank">YouSee</a>
		</p>
      </div>
</div>
</body>
</html>