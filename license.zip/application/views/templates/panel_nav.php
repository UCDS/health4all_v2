<div class="col-sm-3 col-md-2">
  <ul class="nav nav-pills nav-stacked">
	<li <?php if(current_url()==base_url()."user_panel/place"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/user_panel/place">Place</a></li>
	<li <?php if(current_url()==base_url()."user_panel/donation_summary"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/user_panel/donation_summary">Reports</a></li>
	<li <?php if(current_url()==base_url()."create_slots"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/user_panel/create_slots">Create Slots</a></li>
	<li <?php if(current_url()==base_url()."register"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/register">Walk In</a></li>
	<li <?php if(current_url()==base_url()."register/donation"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/register/donation">Medical Checkup</a></li>
	<li <?php if(current_url()==base_url()."register/bleeding"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/register/bleeding">Bleeding</a></li>
	<li <?php if(current_url()==base_url()."inventory/blood_grouping"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/inventory/blood_grouping">Grouping</a></li>
	<li <?php if(current_url()==base_url()."inventory/prepare_components"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/inventory/prepare_components">Component Preparation</a></li>
	<li <?php if(current_url()==base_url()."inventory/screening"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/inventory/screening">Screening</a></li>
	<li <?php if(current_url()==base_url()."register/request"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/register/request">Request</a></li>
	<li <?php if(current_url()==base_url()."inventory/issue"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/inventory/issue">Issue</a></li>
	<li <?php if(current_url()==base_url()."inventory/discard"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/inventory/discard">Discard</a></li>
	<li <?php if(current_url()==base_url()."staff/logout"){ echo "class='active'";}?>><a href="<?php echo base_url();?>bloodbank/staff/logout">Logout</a></li>

  </ul>
  
</div>