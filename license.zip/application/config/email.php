<?php
$config['protocol']='smtp';
$config['mail_path'] = 'localhost';
$config['smtp_host']='localhost';
$config['mailtype']='html';
?>
